Casino Suits Fix v1.1
Author: zedas
Oct 10, 2017


This mod puts the right suits on the right factions, those being the Chairmen and the Omertas. The Chairmen were always supposed  
to wear dark suits (Grimy pre-war businesswear) and the Omertas were supposed to wear light suits (Dirty pre-war businesswear) so  
they would be visually distinct from one another, but because of some errors in the data files this never happened. This mod corrects 
that problem, fixes a couple other issues, and has a little extra as well. This particular fix has been done before a couple  
times, but none of those did exactly what I wanted, so I put this mod together for myself and decided I'd post it here in case  
anyone else is looking for the same thing. 


What does it do exactly?

-fixes the texture on female version of the Dirty pre-War Businesswear (it was using Kimball's suit texture)
-fixes the texture on the MALE version of the Grimy pre-War Businesswear (it was using Dirty Businesswear texture)

-puts Grimy businesswear on all the Chairmen
-puts Dirty (the light coloured) businesswear to all of the Omertas (except for Nero, see card)
-puts a unique version of the businesswear on Gomorrah dealers to make them more visually distinct
-gives a possibility for Gomorrah dealers to wear gambling visor

-puts the Dirty pre-war businesswear on the Garret Twins as per the original concept (see card) 


Installation: 

1) Unzip the contents of the archive into your Fallout New Vegas directory. If asked to overwrite choose "Yes"

2) In your "Data Files" menu, or in FOMM, or in whatever you're using place a checkmark beside the Casino Suits Fix.esp


Compatibility/Known Issues:

This mod will not be compatible with any other mod that alters particular members of Chairmen, particular members of the Omertas (e.g. New Vegas Redesigned 3),  
or the pre-war businesswear armour type. The conflicts probably won't be game breaking, they'll just wipe out the changes to those references that either mod has made. This mod carries forward any pertinent fixes from YUP.


Feedback:

Any comments, CONSTRUCTIVE criticism, or pointers will be greatly appreciated. Please leave them in the comments section or send  
me a message. You can also find me doodling around the Bethsoft forums.


Changelog:
v1.1
Oct 10, 2017
- Changed Dealer Suit to non-playable
- Fixed some incorrect texture assignments on female Grimy Businesswear
- Added proper suits to three Omerta instances I missed
- Removed redundant leveled item
- Harmonized with Yukichigai Unofficial Patch (though this still has a few fixes it does not)
- Added new gambling visor Gomorrah dealers have possibility of wearing
- Added description and bash tag to file header
		
v1.0 
Feb 13, 2012
- Initial release


Credits/Thanks:

- Visor mesh from Headgear Is Important - Headgear Pack by hagyjalbeken
- Thanks to Obsidian and Bethesda for Fallout New Vegas and the tools to allow me to muck with it.

