Nida schuetlich outfit for Type3
Author: Fizz
Version: 1.0
Date: 2011/02/01

===============
Description:
===============

This mod adds new set of clothes.


===============
Location:
===============

see screenshot for the location


===============
Requirements:
===============

BEWARE OF GIRL Type 3 HiRez HiDetailed Replacer
http://www.newvegasnexus.com/downloads/file.php?id=34702
or
DIMONIZED TYPE3 female body WIP
http://www.fallout3nexus.com/downloads/file.php?id=4280

===============
Install:
===============

1. Extract the files from the archive.
2. Copy files to (install folder)\Fallout New Vegas\Data\
3. Start Fallout New Vegas Launcher, click 'Data Files', place a check-mark beside the Nidaoutfitv1.esp file.

===============
Un-Install:
===============

1. Start Fallout Launcher, click Data Files, uncheck the Nidaoutfitv1.esp file.
2. Delete the files/folders associated with the mod.

===============
Credits:
===============

Thanks to Bethesda for creating Fallout New Vegas.
Thanks to InsanitySorrow for ReadMe Generator this readme is based on.
Thanks to dimon99 for type 3 body.

