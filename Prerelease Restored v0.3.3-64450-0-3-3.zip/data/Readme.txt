Prerelease: Restored!
by Umbersona

v0.3.3
Goodsprings Cemetery
 -Enabled a static shovel
 -Incorporated tranquilTulip's Goodsprings Cemetery Shovel Restored

McCarran
 -Added 5 traffic Cones to McCarran Road, one of which has a mine under it
 -Added a bus stop at the gas station across from McCarran

Vikki and Vance
 -Added 3 beers to the bar area

Mojave Outpost
 -Added two checkpoints and repositioned a car I placed earlier

Gomorrah
 -Restored 2 caged dancing prostitutes
 -Added much vodka behind the bar
 -Added 2 empty scotch bottles behind the bar
 -Added 2 cage sounds to existing cages without them.

Jean
 -Added a camper to the cliffside between Jean and Goodsprings

Caesar's Tent
 -Added a dresser to Caesar's living quarters.

Helios One
 -Added 4 more street lights to Helios

Primm
 -Added a fallen log to the front of the Bison Steve

v0.3.2
Novac
 -Added a 2 trailers just outside town
 -Added a blue car just outside town
 -Added a trailer to the motel, inside the gates

Primm
 -Added three rubble piles around the Bison Steve
 -Added a wrecked car in front of the Bison Steve
 -Addeed the no parking sign in front of Bison Steve

Helios One
 -Added 4 industrial machines (with sound) to the back of the main building
 -Added 3 street lights to the facility
 -Added 4 diesel tanks to the side of Helios
 -Added stairs to back entrance of Helios

Gomorrah
 -Replaced a standard dancer cage with the unused green cage (as seen in xbox 360 version)

Highway 95 Viper Camp
 -Added cab from overturned Semi

Nellis AFB
 -Added concrete barricade near hangars

King's School
 -Added 2 beers to the front counter
 -Added a radio to the front counter

Mojave Outpost
 -Added a car at the base of the ranger statue

NCR Sharecropper Farms
 -Added Buffalo Gourd Seed just ooutside front gate

Freeside East Gate
 -Added an Atomic Wrangler billboard outside

Nipton
 -Added 2 cacti in front of a house

McCarran
 -Restored 7 planters to the front of McCarran, including two which use the (until now) unused overturned planter model

v0.3.1
Westside (Outside)
 -Added light to playground (present in NVmini world)
 -Added sandbags to barricade (present in NVmini world)
 -Added ramp to barricade (Present in NVmini world)
 -Replaced 2 car hulkS with intact carS (present in NVmini)
 -Replaced 1 geberic barricade with a truck trailer (present in NVmini)

McCarran
 -Replaced car hulk with Police Car (intro video)

Powder Ganger Camp West
 -Added 2 ammo boxes under the table
 -Added 2 bottles of beer on the table
 -Added milk crate near one of the chairs

v0.3 adds
McCarran (Outside)
 -A tire stack beside the gate (present in the NVmini world)
 -Flaming barrel near car crash
 -Flaming barrel near McCarran gate
 -Flaming barrel added near New Vegas sign
 -Bus stop added near McCarran
 -Flaming barrel near bus stop
 -Graffiti near McCarran entrance

Novac
 -2 Joshua Trees inside the Dinosaur gate
 -A Joshua tree outside the gate by the bridge
 -A mailbox in front of Motel (from ending slide)

Road to Primm from Jean
 -Replaces 1 car hulk with an intact vehicle

Nipton
 -Added scrap shed to side of general store

v0.2 adds
Helios One
 -Scrap Tents over the beds out in the open

v0.1

Goodsprings
 -Wooden Crate added to pile of cargo in front of General Store
 -2 Wooden Crates added to General Store's porch
 -Tire Stack added to side of cart in front of General Store
 -Urban Trashcan added to opposite side of cart in front of General Store
 -Picnic Table added in the Alley between the Saloon and the General Store
 -Joshua Tree added in front of Saloon
 -Water Tank added behind Saloon

Mojave Outpost
 -Car added to the road in front of the Outpost

Primm
 -Opened up a ruined building next to the NCR tents
 -Moved a couch blocking the entrance to the side of the building